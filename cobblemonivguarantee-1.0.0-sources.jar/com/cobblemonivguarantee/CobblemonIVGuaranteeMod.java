package com.cobblemonivguarantee;

import net.fabricmc.api.ModInitializer;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class CobblemonIVGuaranteeMod implements ModInitializer {

    public static final String MOD_ID = "cobblemonivguarantee";
    public static final Logger LOGGER = LoggerFactory.getLogger(MOD_ID);

    @Override
    public void onInitialize() {
        LOGGER.info("[CobblemonIVGuarantee] Mod carregado! " +
                    "Pokémon lendários, míticos, Ultra Beasts, Paradox e fósseis " +
                    "receberão pelo menos 3 IVs perfeitos ao spawnar.");
    }
}
