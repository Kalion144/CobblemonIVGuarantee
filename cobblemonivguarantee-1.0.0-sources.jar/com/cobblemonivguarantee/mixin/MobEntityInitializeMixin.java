package com.cobblemonivguarantee.mixin;

import com.cobblemon.mod.common.entity.pokemon.PokemonEntity;
import com.cobblemon.mod.common.pokemon.IVs;
import com.cobblemon.mod.common.pokemon.Pokemon;
import com.cobblemon.mod.common.pokemon.Species;
import com.cobblemon.mod.common.api.pokemon.stats.Stats;
import com.cobblemonivguarantee.CobblemonIVGuaranteeMod;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Set;
import net.minecraft.class_1266;
import net.minecraft.class_1308;
import net.minecraft.class_1315;
import net.minecraft.class_3730;
import net.minecraft.class_5425;

/**
 * Mixin aplicado em MobEntity.initialize().
 *
 * Por que MobEntity e não PokemonEntity?
 *   - Se PokemonEntity não sobrescrever initialize(), o método herda de MobEntity
 *     e o Mixin precisa estar na classe que define o método.
 *   - A verificação instanceof garante que o código só roda para PokemonEntity.
 *
 * initialize() é chamado apenas no spawn natural/comando, NUNCA ao carregar
 * entidades salvas no disco, então não há risco de sobrescrever IVs de Pokémon
 * que o jogador já possui.
 */
@Mixin(class_1308.class)
public abstract class MobEntityInitializeMixin {

    // -----------------------------------------------------------------------
    // Constantes
    // -----------------------------------------------------------------------

    /** Todos os seis stats possíveis de IV. */
    private static final Stats[] ALL_STATS = {
        Stats.HP,
        Stats.ATTACK,
        Stats.DEFENCE,
        Stats.SPECIAL_ATTACK,
        Stats.SPECIAL_DEFENCE,
        Stats.SPEED
    };

    /**
     * Labels usadas pelo Cobblemon nos arquivos JSON de espécie.
     * Estão em minúsculo — a comparação é feita com toLowerCase() para segurança.
     *
     * Se o Cobblemon mudar algum label, basta atualizar esta constante.
     */
    private static final Set<String> SPECIAL_LABELS = Set.of(
        "legendary",
        "mythical",
        "ultra_beast",  // pode aparecer também como "ultrabeast" em alguns datapack
        "ultrabeast",
        "paradox",
        "fossil"
    );

    /** Quantidade mínima de IVs perfeitos (valor 31) garantidos. */
    private static final int MIN_PERFECT_IVS = 3;

    // -----------------------------------------------------------------------
    // Mixin
    // -----------------------------------------------------------------------

    /**
     * Injeta ao fim de MobEntity.initialize() para interceptar o spawn de Pokémon.
     *
     * Assinatura do método alvo em Minecraft 1.21.1 (Yarn mappings):
     *   EntityData initialize(ServerWorldAccess, LocalDifficulty, SpawnReason, EntityData)
     */
    @Inject(
        method = "initialize(Lnet/minecraft/world/ServerWorldAccess;" +
                              "Lnet/minecraft/world/LocalDifficulty;" +
                              "Lnet/minecraft/entity/SpawnReason;" +
                              "Lnet/minecraft/entity/EntityData;)" +
                              "Lnet/minecraft/entity/EntityData;",
        at = @At("RETURN")
    )
    private void cobblemonivguarantee$onInitialize(
            class_5425 world,
            class_1266 difficulty,
            class_3730 spawnReason,
            class_1315 entityData,
            CallbackInfoReturnable<class_1315> cir) {

        // 1. Verificar se o mob é um PokemonEntity
        if (!((Object) this instanceof PokemonEntity pokemonEntity)) {
            return;
        }

        // 2. Obter o objeto Pokemon e sua espécie
        Pokemon pokemon = pokemonEntity.getPokemon();
        if (pokemon == null) return;

        Species species = pokemon.getSpecies();
        if (species == null) return;

        // 3. Verificar se pertence a alguma categoria especial via labels
        if (!isSpecialPokemon(species)) return;

        // 4. Garantir mínimo de IVs perfeitos
        IVs ivs = pokemon.getIvs();
        guaranteeMinPerfectIVs(ivs, MIN_PERFECT_IVS);

        // 5. Log de debug (visível apenas com logging em nível DEBUG)
        if (CobblemonIVGuaranteeMod.LOGGER.isDebugEnabled()) {
            CobblemonIVGuaranteeMod.LOGGER.debug(
                "[CobblemonIVGuarantee] {} spawnou com IVs garantidos — " +
                "HP:{} ATK:{} DEF:{} SPA:{} SPD:{} SPE:{}",
                species.getName(),
                ivs.get(Stats.HP),
                ivs.get(Stats.ATTACK),
                ivs.get(Stats.DEFENCE),
                ivs.get(Stats.SPECIAL_ATTACK),
                ivs.get(Stats.SPECIAL_DEFENCE),
                ivs.get(Stats.SPEED)
            );
        }
    }

    // -----------------------------------------------------------------------
    // Métodos auxiliares (static para não poluir o bytecode do MobEntity)
    // -----------------------------------------------------------------------

    /**
     * Retorna true se a espécie possuir pelo menos um label especial.
     *
     * Cobblemon define os labels em:
     *   data/cobblemon/species/<pokemon>.json  →  campo "labels": ["legendary"]
     *
     * Se um Pokémon do datapack "Cobblemon Spawn Legendaries" usar labels corretos,
     * este método os detectará automaticamente.
     */
    private static boolean isSpecialPokemon(Species species) {
        Set<String> labels = species.getLabels();
        if (labels == null || labels.isEmpty()) return false;

        for (String label : labels) {
            if (SPECIAL_LABELS.contains(label.toLowerCase())) {
                return true;
            }
        }
        return false;
    }

    /**
     * Garante que o Pokémon possua pelo menos {@code minCount} IVs com valor 31.
     *
     * Algoritmo:
     *   1. Conta IVs já perfeitos.
     *   2. Se já tiver o suficiente, não faz nada (preserva IVs naturalmente altos).
     *   3. Caso contrário, embaralha os stats restantes e define os necessários como 31.
     *
     * O resultado é sempre ≥ minCount IVs perfeitos, preservando os demais
     * valores aleatórios gerados pelo Cobblemon.
     *
     * Nota sobre a API do Cobblemon:
     *   ivs.get(stat)      → int  (retorna 0 se não definido)
     *   ivs.set(stat, val) → void (o Cobblemon faz coerceIn(0, 31) internamente)
     *
     *   Stats é uma Kotlin enum, acessível em Java como Stats.HP, Stats.ATTACK, etc.
     */
    private static void guaranteeMinPerfectIVs(IVs ivs, int minCount) {
        List<Stats> notPerfect = new ArrayList<>(ALL_STATS.length);
        int perfectCount = 0;

        for (Stats stat : ALL_STATS) {
            int value = ivs.get(stat);   // retorna int (primitivo)
            if (value >= 31) {
                perfectCount++;
            } else {
                notPerfect.add(stat);
            }
        }

        // Já possui IVs suficientes — não altera nada
        if (perfectCount >= minCount) return;

        int needed = minCount - perfectCount;

        // Embaralha para distribuição aleatória dos IVs perfeitos
        Collections.shuffle(notPerfect);

        for (int i = 0; i < needed && i < notPerfect.size(); i++) {
            ivs.set(notPerfect.get(i), 31);
        }
    }
}
